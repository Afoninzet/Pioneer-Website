/**

- Firebase синхронизация для календаря репетиций
- Обеспечивает синхронизацию отметок между всеми устройствами
*/

let firebaseEnabled = false;
let firebaseDB = null;
let currentListener = null;

function initFirebase() {
if (typeof window.firebaseDB !== 'undefined' && window.firebaseDB) {
firebaseDB = window.firebaseDB;
firebaseEnabled = true;
console.log('Firebase инициализирован');
return true;
}
console.log('Firebase не доступен, работаем в офлайн режиме');
return false;
}

initFirebase();